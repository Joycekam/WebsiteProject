window.onload = function() {
  const header__title = document.querySelector('.header__title');
  header__title.classList.remove('hidden');
  const section = document.querySelector('.section');
  section.classList.remove('hidden');
}